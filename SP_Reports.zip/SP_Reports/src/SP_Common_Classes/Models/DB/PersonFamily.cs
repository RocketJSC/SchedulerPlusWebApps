﻿using System;
using System.Collections.Generic;

namespace SP_Common_Classes.Models.DB
{
    public partial class PersonFamily
    {
        public int PersonId { get; set; }
    }
}
