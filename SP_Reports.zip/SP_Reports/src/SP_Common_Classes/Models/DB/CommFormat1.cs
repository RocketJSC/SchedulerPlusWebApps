﻿using System;
using System.Collections.Generic;

namespace SP_Common_Classes.Models.DB
{
    public partial class CommFormat1
    {
        public int PersonId { get; set; }
        public int FamilyId { get; set; }
        public int EventId { get; set; }
    }
}
