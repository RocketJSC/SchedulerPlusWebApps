﻿using System;
using System.Collections.Generic;

namespace SP_Common_Classes.Models.DB
{
    public partial class OwUser
    {
        public string UserId { get; set; }
        public string Password { get; set; }
    }
}
