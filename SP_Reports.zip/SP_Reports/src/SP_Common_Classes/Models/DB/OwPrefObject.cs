﻿using System;
using System.Collections.Generic;

namespace SP_Common_Classes.Models.DB
{
    public partial class OwPrefObject
    {
        public int PrefId { get; set; }
        public string PrefName { get; set; }
        public int PrefType { get; set; }
    }
}
