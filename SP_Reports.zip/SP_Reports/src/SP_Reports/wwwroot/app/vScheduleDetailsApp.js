﻿(function () {
    'use strict';
    var app = angular.module('vScheduleDetailsApp', []);
})();
